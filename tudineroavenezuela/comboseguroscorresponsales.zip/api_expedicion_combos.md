
# Api expedición producto combo seguro

En esta documentación, se encontrará toda la información relevante para hacer uso del servicio de expedición para el producto de combos.

## Objetivos del API

El propósito de este API es realizar una expedición del producto combos, para ello la información enviada debe superar las políticas que el negocio tiene configuradas, de ser así el api generara la expedición y devolverá los identificadores de la póliza en dos sistemas de sura, el número de negocio y el número de póliza, además de la prima neta, impuestos y prima total. En caso de fallar las políticas, indicara que hay un error y detallara las inconsistencias.

## Como consumir el API

El API es un servicio REST el cual debe ser consumido con las siguientes características

- **Endpoint:** El endpoint del servicio es `https://apisuratest.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/expedicion`
- **Método REST:** El método REST de este servicio es `POST`
- **Headers:** El header que debe ser enviado para realizar el consumo es `x-apikey: <<api-key proporcionado para el aliado>>`
- **Body:** La plantilla del Body que se detallara a continuación será explicada a fondo en la siguiente sección [Descripción del Body](#seccionBody)

Plantilla del Body:

```json
{
    "contenido": [
        {
            "Tipo de documento Tomador/Asegurado": "",
            "Número de documento Tomador/Asegurado": "",
            "Primer Nombre Tomador/Asegurado": "",
            "Segundo Nombre Tomador/Asegurado": "",
            "Primer Apellido Tomador/Asegurado": "",
            "Segundo Apellido Tomador/Asegurado": "",
            "Fecha Nacimiento Asegurado": "",
            "Genero": "",
            "Plan": "",
            "Fecha Inicio de Vigencia": "",
            "Forma de pago": "",
            "Valor asegurado vida": "",
            "Medio de pago": "",
            "Nombre del banco": "",
            "Tipo de cuenta": "",
            "Numero de cuenta": "",
            "Confirmar número de cuenta": "",
            "Tipo documento cuentahabiente": "",
            "Número documento cuentahabiente": "",
            "Primer nombre cuentahabiente": "",
            "Segundo nombre cuentahabiente": "",
            "Primer apellido cuentahabiente": "",
            "Segundo apellido cuentahabiente": "",
            "Código del vendedor": "",
            "Confirmar código del vendedor": "",
            "Ciudad de Residencia Tomador/Asegurado": "",
            "Direccion del Tomador/Asegurado": "",
            "Correo electronico del Tomador/Asegurado": "",
            "Telefono Tomador/Asegurado": "",
            "Celular Tomador/Asegurado": "",
            "Autoriza el tratamiento de Datos": "",
            "Autoriza el envío de mensajes de texto": "",
            "Autoriza el envío de correos electrónicos": "",
            "Posee beneficiario 1": "",
            "Tipo de documento Beneficiario 1": "",
            "Numero de documento Beneficiario 1": "",
            "Primer Nombre Beneficiario 1": "",
            "Segundo Nombre Beneficiario 1": "",
            "Primer Apellido Beneficiario 1": "",
            "Segundo Apellido Beneficiario 1": "",
            "Porcentaje de distribuccion beneficiario 1": "",
            "Posee beneficiario 2": "",
            "Tipo de documento Beneficiario 2": "",
            "Numero de documento Beneficiario 2": "",
            "Primer Nombre Beneficiario 2": "",
            "Segundo Nombre Beneficiario 2": "",
            "Primer Apellido Beneficiario 2": "",
            "Segundo Apellido Beneficiario 2": "",
            "Porcentaje distribuccion beneficiario 2": "",
            "Posee beneficiario 3": "",
            "Tipo de documento Beneficiario 3": "",
            "Numero de documento Beneficiario 3": "",
            "Primer Nombre Beneficiario 3": "",
            "Segundo Nombre Beneficiario 3": "",
            "Primer Apellido Beneficiario 3": "",
            "Segundo Apellido Beneficiario 3": "",
            "Porcentaje distribuccion beneficiario 3": ""
        }
    ]
}
```


## <a name="seccionBody"></a> Descripción del Body

| Nombre del campo | Descripción | Longitud Máxima | Requerido | Posee catalogo |
|:--------------------------------:|:------------------------------------------------------------------------------------------------------------------------------------------------:|:---------------:|:------------------------------------------------------------------:|:--------------:|
| Código del vendedor | Este campo indica el código del aliado ante sura y sera proporcionado por el area de negocio de corresponsales | 6 | Si | No |
| Confirmar código del vendedor | Este campo confirma el código del aliado ante sura y debera ser el mismo digitado en Código del vendedor | 6 | Si | No |
| Tipo de documento Tomador/Asegurado | Este campo indica que tipo de documento posee el tomador/asegurado | 6 | Si | Si |
| Número de documento Tomador/Asegurado | Este campo indica el número de documento del tomador/asegurado, solo se permite ingresar números. | 10 | Si | No |
| Primer Nombre Tomador/Asegurado | Este campo indica el primer nombre del tomador/asegurado | 50 | Si | No |
| Segundo Nombre Tomador/Asegurado | Este campo indica el segundo nombre del tomador/asegurado | 20 | No | No |
| Primer Apellido Tomador/Asegurado | Este campo indica el primer apellido del tomador/asegurado | 20 | No | No |
| Segundo Apellido Tomador/Asegurado | Este campo indica el segundo apellido del tomador/asegurado | 20 | No | No |
| Tipo documento cuentahabiente | Este campo indica que tipo de documento posee el cuentahabiente | 6 | Si | Si |
| Número documento cuentahabiente | Este campo indica el número de documento del cuentahabiente, solo se permite ingresar números. | 10 | Si | No |
| Primer nombre cuentahabiente | Este campo indica el primer nombre del cuentahabiente | 20 | Si | No |
| Segundo nombre cuentahabiente | Este campo indica el segundo nombre del cuentahabiente | 20 | No | No |
| Primer apellido cuentahabiente | Este campo indica el primer apellido del cuentahabiente | 20 | Si | No |
| Segundo apellido cuentahabiente | Este campo indica el segundo apellido del cuentahabiente | 20 | No | No |
| Fecha Nacimiento Asegurado | Este campo indica la fecha de nacimiento del asegurado en el formato aaaammdd | 8 | Si | No |
| Genero | Este campo indica el género del asegurado | 9 | Si | Si |
| Fecha Inicio de Vigencia | Este campo indica la fecha en que se realiza la expedición en el formato aaaammdd | 8 | Si | No |
| Plan | Este campo indica que plan se está expidiendo del producto  combos | 30 | Si | Si |
| Forma de pago | Este campo indica la periodicidad de pago con la cual se  pagaría el producto | 10 | Si | Si |
| Valor asegurado vida | Este campo indica el valor asegurado que tendrá la cobertura de vida | 7 | Si | Si |
| Medio de pago | Este campo indica porque medio se realizar el cobro de la póliza | 20 | Si | Si |
| Nombre del banco | Este campo indica el código del banco del cual se hará el débito automático en caso de que el medio de cobro sea débito automático. | 20 | Es requerido si en Medio de cobro se especifica débito  automático | Si |
| Tipo de cuenta | Este campo indica el tipo de cuenta del cual se hará el débito automático en caso de que el medio de cobro sea débito automático. | 20 | Es requerido si en Medio de cobro se especifica débito  automático | Si |
| Número de cuenta | Este campo indica el número de cuenta del cual se hará el débito automático en caso de que el medio de cobro sea débito automático. | 20 | Es requerido si en Medio de cobro se especifica débito  automático | No |
| Confirmar número de cuenta | Este campo se pide confirmar el número de cuenta del cual se  hará el débito automático en caso de que el medio de cobro  sea débito automático. | 20 | Es requerido si en Medio de cobro se especifica débito  automático | No |
| Ciudad de Residencia Tomador/Asegurado | Este campo indica la ciudad del tomador/asegurado | 45 | No | Si |
| Direccion del Tomador/Asegurado | Este campo indica la dirección del tomador/asegurado | 80 | No | No |
| Correo electronico del Tomador/Asegurado | Este campo indica el correo del tomador/asegurado | 40 | Si | No |
| Autoriza el tratamiento de Datos | Este campo indica si el tomador/asegurado acepta el tratamiento de datos | 2 | Si | Si |
| Autoriza el envío de mensajes de texto | Este campo indica si el tomador/asegurado autoriza a enviar la información vía sms | 2 | Si | Si |
| Autoriza el envío de correos electrónicos | Este campo indica si el tomador/asegurado autoriza a enviar la información vía email | 2 | Si | Si |
| Telefono Tomador/Asegurado | Este campo indica el teléfono del tomador/asegurado | 7 | No | No |
| Celular Tomador/Asegurado | Este campo indica el celular del tomador/asegurado | 10 | Si | No |
| Posee beneficiario 1 | Indica si se diligenciara la información de beneficiario 1 | 2 | Si | Si |
| Tipo de documento Beneficiario 1 | Indica el tipo de documento del beneficiario 1 | 20 | No | Si |
| Numero de documento Beneficiario 1 | Indica el número de documento del beneficiario 1 | 15 | No | No |
| Primer Nombre Beneficiario 1 | Indica el primer nombre del beneficiario 1 | 20 | Es obligatorio si se dijo que si posee beneficiario 1 | No |
| Segundo Nombre Beneficiario 1 | Indica el segundo nombre del beneficiario 1 | 20 | No | No |
| Primer Apellido Beneficiario 1 | Indica el primer apellido del beneficiario 1 | 20 | Es obligatorio si se dijo que si posee beneficiario 1 | No |
| Segundo Apellido Beneficiario 1 | Indica el segundo apellido del beneficiario 1 | 20 | No | No |
| Porcentaje beneficiario 1 | Indica el porcentaje del valor asegurado que será dado al beneficiario 1 si ocurre el siniestro | 5 | Es obligatorio si se dijo que si posee beneficiario 1 | No |
| Posee beneficiario 2 | Indica si se diligenciara la información de beneficiario 2 | 2 | Si | Si |
| Tipo de documento Beneficiario 2 | Indica el tipo de documento del beneficiario 2 | 20 | No | Si |
| Numero de documento Beneficiario 2 | Indica el número de documento del beneficiario 2 | 15 | No | No |
| Primer Nombre Beneficiario 2 | Indica el primer nombre del beneficiario 2 | 20 | Es obligatorio si se dijo que si posee beneficiario 2 | No |
| Segundo Nombre Beneficiario 2 | Indica el segundo nombre del beneficiario 2 | 20 | No | No |
| Primer Apellido Beneficiario 2 | Indica el primer apellido del beneficiario 2 | 20 | Es obligatorio si se dijo que si posee beneficiario 2 | No |
| Segundo Apellido Beneficiario 2 | Indica el segundo apellido del beneficiario 2 | 20 | No | No |
| Porcentaje beneficiario 2 | Indica el porcentaje del valor asegurado que será dado al beneficiario 2 si ocurre el siniestro | 5 | Es obligatorio si se dijo que si posee beneficiario 2 | No |
| Posee beneficiario 3 | Indica si se diligenciara la información de beneficiario 3 | 2 | Si | Si |
| Tipo de documento Beneficiario 3 | Indica el tipo de documento del beneficiario 3 | 20 | No | Si |
| Numero de documento Beneficiario 3 | Indica el número de documento del beneficiario 3 | 15 | No | No |
| Primer Nombre Beneficiario 3 | Indica el primer nombre del beneficiario 3 | 20 | Es obligatorio si se dijo que si posee beneficiario 3 | No |
| Segundo Nombre Beneficiario 3 | Indica el segundo nombre del beneficiario 3 | 20 | No | No |
| Primer Apellido Beneficiario 3 | Indica el primer apellido del beneficiario 3 | 20 | Es obligatorio si se dijo que si posee beneficiario 3 | No |
| Segundo Apellido Beneficiario 3 | Indica el segundo apellido del beneficiario 3 | 20 | No | No |
| Porcentaje beneficiario 3 | Indica el porcentaje del valor asegurado que será dado al beneficiario 3 si ocurre el siniestro | 5 | Es obligatorio si se dijo que si posee beneficiario 3 | No |

## Políticas de expedición

Las políticas que serán evaluadas previo a la tarifación son las siguientes:

- Se valida que todos los campos requeridos posean un valor, los campos requeridos pueden ser consultado en la anterior tabla.
- Se valida que todos los campos tenga como máximo la longitud especificada en la anterior tabla.
- Se valida que los campos que poseen catálogo, el valor enviado este entre los permitidos por dicho catálogo. para consultar los valores posibles de un catálogo consultar el api `https://apisuratest.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/catalogo` en ambiente de laboratorio o `https://apisura.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/catalogo` en ambiente productivo.
- Se valida que el número de documento solo posea números.
- Se valida que, si el número de documento es de hasta 8 dígitos, el género enviado sea el correcto, analizando los rangos de números de documentos por género que posee la registraduria.
- Se valida que las fechas de nacimiento y fecha de inicio de vigencia tengan el formato aaaammdd.
- Se valida que los nombres solo posean caracteres de la `a` a la `z` incluido minúsculas, mayúsculas y vocales tildadas.
- Se valida que la edad que se calcula de la fecha de nacimiento hasta la fecha de inicio de vigencia, este en el rango de 18 a 70 años.
- Se valida que la periodicidad enviada este entre las periodicidades permitidas para el plan.
- Se valida que el asegurado no posea ya un producto vigente del mismo producto.
- Se valida que el asegurado no este marcado como un riesgo en la compañía y por tanto que no se pueda cotizar ni expedir una póliza por este canal.
- Se valida que el tomador no este marcado como un riesgo en la compañía y por tanto que no se pueda cotizar ni expedir una póliza por este canal.
- Se valida que si se estable que el medio de cobro es debito automático, se debe enviar el banco, el tipo de cuenta y el número de cuenta.
- Se valida que el número de cuenta y numero cuenta confirmación sean iguales.
- Se valida que si se envía que el banco es Bancolombia el número de cuenta sea de 11 dígitos.
- Se valida que el correo tenga la estructura de un correo, es decir un `@` y un dominio.
- Se valida que el número de teléfono sea de 7 dígitos.
- Se valida que el celular sea de 10 dígitos y empiece con los prefijos validos en Colombia.
- Se válida para cada uno de los beneficiarios que si se envía tipo de documento se envíe numero de documento.
- Se válida para cada uno de los beneficiarios que si se envía numero de documento se envíe tipo de documento.
- Se valida que el porcentaje de participación de los beneficiarios no sea mayor que 0.
- Se valida que la suma de porcentaje de participación de todos los beneficiarios sea 100.
- Se valida que si se especifica que si posee cierto beneficiario diligencie como mínimo el primer nombre, primer apellido, parentesco con el asegurado y porcentaje de participación.
- Se valida que el tomador no puede ser beneficiario en la póliza.
- Se valida que el asegurado no puede ser beneficiario en la póliza.


## Ejemplo de consumo API expedición

```json
{
    "contenido": [
        {
            "Tipo de documento Tomador/Asegurado": "CEDULA",
            "Número de documento Tomador/Asegurado": "47200910",
            "Primer Nombre Tomador/Asegurado": "sofia",
            "Segundo Nombre Tomador/Asegurado": "isabel",
            "Primer Apellido Tomador/Asegurado": "ramirez",
            "Segundo Apellido Tomador/Asegurado": "perez",
            "Fecha Nacimiento Asegurado": "19910101",
            "Genero": "Femenino",
            "Plan": "Combo Seguro Anual",
            "Fecha Inicio de Vigencia": "20191204",
            "Forma de pago": "Anual",
            "Valor asegurado vida": "3500000",
            "Medio de pago": "Débito Automático",
            "Nombre del banco": "BANCO BANCOLOMBIA",
            "Tipo de cuenta": "Ahorros",
            "Numero de cuenta": "12345678901",
            "Confirmar número de cuenta": "12345678901",
            "Tipo documento cuentahabiente": "CEDULA",
            "Número documento cuentahabiente": "44100200",
            "Primer nombre cuentahabiente": "Ana",
            "Segundo nombre cuentahabiente": "Maria",
            "Primer apellido cuentahabiente": "Romero",
            "Segundo apellido cuentahabiente": "Castaño",
            "Código del vendedor": "55620",
            "Confirmar código del vendedor": "55620",
            "Ciudad de Residencia Tomador/Asegurado": "MEDELLIN (ANTIOQUIA)",
            "Direccion del Tomador/Asegurado": "CALLE 12 # 12 - 12",
            "Correo electronico del Tomador/Asegurado": "correo@gmail.com",
            "Telefono Tomador/Asegurado": "3213211",
            "Celular Tomador/Asegurado": "3213211212",
            "Autoriza el tratamiento de Datos": "Si",
            "Autoriza el envío de mensajes de texto": "Si",
            "Autoriza el envío de correos electrónicos": "Si",
            "Posee beneficiario 1": "Si",
            "Tipo de documento Beneficiario 1": "CEDULA",
            "Numero de documento Beneficiario 1": "44100201",
            "Primer Nombre Beneficiario 1": "lorena",
            "Segundo Nombre Beneficiario 1": "",
            "Primer Apellido Beneficiario 1": "gutierrez",
            "Segundo Apellido Beneficiario 1": "paz",
            "Porcentaje de distribuccion beneficiario 1": "100",
            "Posee beneficiario 2": "No",
            "Tipo de documento Beneficiario 2": "",
            "Numero de documento Beneficiario 2": "",
            "Primer Nombre Beneficiario 2": "",
            "Segundo Nombre Beneficiario 2": "",
            "Primer Apellido Beneficiario 2": "",
            "Segundo Apellido Beneficiario 2": "",
            "Porcentaje distribuccion beneficiario 2": "",
            "Posee beneficiario 3": "No",
            "Tipo de documento Beneficiario 3": "",
            "Numero de documento Beneficiario 3": "",
            "Primer Nombre Beneficiario 3": "",
            "Segundo Nombre Beneficiario 3": "",
            "Primer Apellido Beneficiario 3": "",
            "Segundo Apellido Beneficiario 3": "",
            "Porcentaje distribuccion beneficiario 3": ""
        }
    ]
}
```

## Ejemplo de respuesta API expedición

Expedición Exitosa:

```json
{
    "estado": "OK",
    "prima_total": 57000,
    "numero_negocio": "CORESEG000236820",
    "numero_poliza": "BAN081837691",
    "impuestos": 0,
    "prima_neta": 57000,
    "mensaje": "Póliza expedida",
    "errores": null
}
```

Expedición Fallida:

```json
{
    "estado": "error",
    "prima_total": null,
    "numero_negocio": null,
    "numero_poliza": null,
    "impuestos": null,
    "prima_neta": null,
    "mensaje": "Se ha presentado inconsistencia en la expedición",
    "errores": [
        {
            "error": "El primer apellido del asegurado solo debe contener letras"
        },
        {
            "error": "El tipo y número de documento no corresponde con el sexo seleccionado"
        }
    ]
}
```

## Status code de respuesta

- `200`: La respuesta es exitosa y retorna los datos de la expedición.
- `409`: La respuesta es fallida debido a que los datos enviados incumplen políticas.
- `500`: Existen problemas técnicos y se requiere notificar a soporte tecnológico. 
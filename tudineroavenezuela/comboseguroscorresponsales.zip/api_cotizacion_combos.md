
# Api cotización producto combo seguro

En esta documentación, se encontrara toda la información relevante para hacer uso del servicio de cotización para el producto de combos.

## Objetivos del API

El propósito de este API es realizar una cotización del producto combos, es decir, que se devuelva la tarifa que el usuario deberá pagar, del plan seleccionado, en la vigencia seleccionada. Esto solo si la información cumple con las políticas mínimas definidas,
devolviendo, la tarifa en el caso en que la información cumpla con las políticas o las inconsistencias en la información en caso que exista un error.

## Como consumir el API

El API es un servicio REST el cual debe ser consumido con las siguientes características

- **Endpoint:** El endpoint del servicio es `https://apisuratest.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/cotizacion` en ambiente de laboratorio y `https://apisura.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/cotizacion` en ambiente productivo.
- **Método REST:** El método REST de este servicio es `POST`
- **Headers:** El header que debe ser enviado para realizar el consumo es `x-apikey: <<api-key proporcionado para el aliado>>`
- **Body:** La plantilla del Body que se detallara a continuación será explicada a fondo en la siguiente sección [Descripción del Body](#seccionBody)

Plantilla del Body:

```json
{
    "contenido": [
        {
            "Tipo de documento Tomador/Asegurado": "",
            "Número de documento Tomador/Asegurado": "",
            "Primer Nombre Tomador/Asegurado": "",
            "Segundo Nombre Tomador/Asegurado": "",
            "Primer Apellido Tomador/Asegurado": "",
            "Segundo Apellido Tomador/Asegurado": "",
            "Fecha Nacimiento Asegurado": "",
            "Genero": "",
            "Plan": "",
            "Fecha Inicio de Vigencia": "",
            "Forma de pago": "",
            "Valor asegurado vida": ""
        }
    ]
}
```


## <a name="seccionBody"></a> Descripción del Body



| Nombre del campo | Descripción | Longitud Máxima | Requerido | Posee catalogo |
|:---------------------------:|:-----------------------------------------------------------------------------------------:|:---------------:|:---------:|:--------------:|
| Tipo de documento Tomador/Asegurado | Este campo indica que tipo de documento posee el Tomador/Asegurado | 6 | Si | Si |
| Número de documento Tomador/Asegurado | Este campo indica el número de documento del Tomador/Asegurado, solo se permite ingresar números. | 10 | Si | No |
| Primer Nombre Tomador/Asegurado | Este campo indica el primer nombre del Tomador/Asegurado | 20 | Si | No |
| Segundo Nombre Tomador/Asegurado | Este campo indica el segundo nombre del Tomador/Asegurado | 20 | No | No |
| Primer Apellido Tomador/Asegurado | Este campo indica el primer apellido del Tomador/Asegurado | 20 | Si | No |
| Segundo Apellido Tomador/Asegurado | Este campo indica el segundo apellido del Tomador/Asegurado | 20 | No | No |
| Fecha Nacimiento Asegurado | Este campo indica la fecha de nacimiento del asegurado en el formato aaaammdd | 8 | Si | No |
| Genero | Este campo indica el género del asegurado | 9 | Si | Si |
| Fecha Inicio de Vigencia | Este campo indica la fecha en que se realiza la cotización en el formato aaaammdd | 8 | Si | No |
| Plan | Este campo indica que plan se está cotizando del producto  combos | 25 | Si | Si |
| Periodicidad de pago | Este campo indica la periodicidad de pago con la cual se  pagaría el producto | 10 | Si | Si |
| Valor asegurado vida | Este campo indica el valor asegurado que tendrá la cobertura de vida | 7 | Si | Si |

## Políticas de cotización

Las políticas que serán evaluadas previo a la tarifación son las siguientes:

- Se valida que todos los campos requeridos posean un valor, los campos requeridos pueden ser consultado en la anterior tabla.
- Se valida que todos los campos tenga como máximo la longitud especificada en la anterior tabla.
- Se valida que los campos que poseen catálogo el valor enviado este entre los permitidos por este catálogo, para consultar los valores posibles de un catálogo consultar el api `https://apisuratest.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/catalogo` en ambiente de laboratorio o `https://apisura.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/catalogo` en ambiente productivo.
- Se valida que el número de documento solo posea números.
- Se valida que, si el número de documento es de hasta 8 dígitos, el género enviado sea el correcto analizando los rangos de números de documentos por género que posee la registraduria.
- Se valida que las fechas de nacimiento y fecha de inicio de vigencia tengan el formato aaaammdd.
- Se valida que los nombres solo posean caracteres de la `a` a la `z` incluido minúsculas, mayúsculas y vocales tildadas.
- Se valida que la edad que se calcula de la fecha de nacimiento hasta la fecha de inicio de vigencia, este en el rango de 18 a 70 años.
- Se valida que la periodicidad enviada este entre las periodicidades permitidas para el plan.
- Se valida que el asegurado no posea ya un producto vigente del mismo producto.
- Se valida que el asegurado no este marcado como un riesgo en la compañía y por tanto que no se pueda cotizar ni expedir una póliza por este canal.

## Ejemplo de consumo API cotización

```json
{
    "contenido": [
        {
            "Tipo de documento Tomador/Asegurado": "CEDULA",
            "Número de documento Tomador/Asegurado": "44200910",
            "Primer Nombre Tomador/Asegurado": "sofia",
            "Segundo Nombre Tomador/Asegurado": "isabel",
            "Primer Apellido Tomador/Asegurado": "ramirez",
            "Segundo Apellido Tomador/Asegurado": "perez",
            "Fecha Nacimiento Asegurado": "19910101",
            "Genero": "Femenino",
            "Plan": "Combo Seguro Mensual Semestral",
            "Fecha Inicio de Vigencia": "20191204",
            "Forma de pago": "Mensual",
            "Valor asegurado vida": "3500000"
        }
    ]
}
```

## Ejemplo de respuesta API cotización

Cotización Exitosa:

```json
{
    "estado": "OK",
    "prima_total": 33600,
    "impuestos": 0,
    "prima_neta": 33600,
    "mensaje": "Póliza cotizada",
    "errores": null
}
```

Cotización Fallida:

```json
{
    "estado": "error",
    "prima_total": null,
    "impuestos": null,
    "prima_neta": null,
    "mensaje": "Se ha presentado inconsistencia en la cotización",
    "errores": [
        {
            "error": "El segundo nombre del asegurado solo debe contener letras"
        }
    ]
}
```

## Status code de respuesta

- `200`: La respuesta es exitosa y retorna una tarifación.
- `409`: La respuesta es fallida debido a que los datos enviados incumplen políticas.
- `500`: Existen problemas técnicos y se requiere notificar a soporte tecnológico. 



# Api catálogos producto combo seguro

En esta documentación, se encontrara toda la información relevante para hacer uso del servicio de consulta de catálogos para el producto de combos.

## Objetivos del API

El propósito de este API es brindar un medio de consulta de los valores de los múltiples catálogos que posee el api para el producto de combos, los cuales son los valores que aceptara ese API en dichos campos.

## Como consumir el API

El API es un servicio REST el cual debe ser consumido con las siguientes características

- **Endpoint:** El endpoint del servicio es `https://apisuratest.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/catalogo` en ambiente de laboratorio o `https://apisura.segurossura.com/api/v1/canalesmasivos/seguro_corresponsales/catalogo` en ambiente productivo.
- **Método REST:** El método REST de este servicio es `POST`
- **Headers:** El header que debe ser enviado para realizar el consumo es `x-apikey: <<api-key proporcionado para el aliado>>`
- **Body:** A continuación se detalla la plantilla de consumo para este API

```json
{
   "campo":""
}
```

En `campo` debe ir el nombre del campo al cual se le quiere consultar el catálogo.

## Ejemplo de consumo API cotización

```json
{
   "campo":"Plan"
}
```

## Ejemplo de respuesta API cotización

Cotización Exitosa:

```json
[
    "Combo Seguro",
    "Combo Seguro Anual"
]
```

Cotización Fallida:

```json
{
    "error": "El catalogo consultado no existe."
}
```

## Status code de respuesta

- `200`: La respuesta es exitosa y retorna los catálogos.
- `404`: El catálogo buscado no existe para el producto combos.
- `500`: Existen problemas técnicos y se requiere notificar a soporte tecnológico.